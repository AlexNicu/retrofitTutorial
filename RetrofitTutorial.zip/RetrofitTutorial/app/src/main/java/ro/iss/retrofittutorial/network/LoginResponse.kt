package com.iss.finestmobile.network


data class LoginResponse(
    val token : String?

)