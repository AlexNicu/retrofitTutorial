package com.iss.finestmobile.network

import com.google.gson.GsonBuilder
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
class RetrofitClientInstance {
    private var retrofit: Retrofit? = null
    private val BASE_URL = "https://smart-academy-demo.herokuapp.com/"
    fun getRetrofitInstance(): Retrofit? {
        if (retrofit == null) {
            retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL) //Set the API base URL.
                .addConverterFactory(GsonConverterFactory.create()) //Add converter factory for serialization and deserialization of objects.
                //used to convert the JSON data to Java objects
                .build() //Create the Retrofit instance using the configured values.
        }
        return retrofit
    }
    fun getRetrofitInstance(token : String): Retrofit? {
        val client = OkHttpClient.Builder().addInterceptor(object : Interceptor {
            @Throws(IOException::class)
            override fun intercept(chain: Interceptor.Chain): okhttp3.Response? {
                val newRequest: Request = chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer $token")
                    .build()
                return chain.proceed(newRequest)
            }
        }).build()
        if (retrofit == null) {
            retrofit = Retrofit.Builder()
                .client(client) //The HTTP client used for requests.
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
        return retrofit
    }
}