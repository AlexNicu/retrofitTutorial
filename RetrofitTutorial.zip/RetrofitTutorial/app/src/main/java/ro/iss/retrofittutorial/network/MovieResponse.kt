package com.iss.finestmobile.network

import ro.iss.retrofittutorial.network.apiModels.Movie


data class MovieResponse (
    val movieList : List<String>
)