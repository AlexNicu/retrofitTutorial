package ro.iss.retrofittutorial.network.apiModels

class Movie(var movie: String) {
}