package ro.iss.retrofittutorial.network.apiModels

/*
 * TODO -> User ar trebui sa fie in apiModel
 *  DONE
 */

class User(var email: String, var password: String) {
}