package ro.iss.retrofittutorial.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iss.finestmobile.fragments.invoiceDetails.adapter.MovieAdapter
import com.iss.finestmobile.network.MovieListAPICallsInterface
import com.iss.finestmobile.network.MovieResponse
import com.iss.finestmobile.network.RetrofitClientInstance
import kotlinx.android.synthetic.main.activity_movie_list.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import ro.iss.retrofittutorial.R

class MovieListActivity : AppCompatActivity() {
    var recyclerView:RecyclerView?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_list)

        val accessToken=intent.getStringExtra("accessToken")
        recyclerView = dashboard_list_bills as RecyclerView

       accessToken?.let {
           getSearchedMoviesResponse(it)
       }
    }

    fun getMoviesResponse(accessToken: String){
        val service = RetrofitClientInstance().getRetrofitInstance(accessToken)?.create<MovieListAPICallsInterface>(
            MovieListAPICallsInterface::class.java)
        accessToken.let {
            val request = service?.getMovieListData()
            request?.enqueue(object : Callback<MovieResponse> {
                override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
                    Log.i("MovieApiCall", "Fail")
                    Log.i("MovieApiCall", t.message.toString())
                }

                override fun onResponse(
                    call: Call<MovieResponse>,
                    response: Response<MovieResponse>
                ) {
                    recyclerView?.apply {
                        layoutManager = LinearLayoutManager(context)
                        adapter = response.body()?.let { it1 -> MovieAdapter(it1) }
                        adapter?.notifyDataSetChanged()
                    }
                    Log.i("MovieApiCall", "Successfull")
                    Log.i("MovieApiCall", response.toString())
                }
            })
        }


    }

    fun getSearchedMoviesResponse(accessToken: String){
        val service = RetrofitClientInstance().getRetrofitInstance(accessToken)?.create<MovieListAPICallsInterface>(
            MovieListAPICallsInterface::class.java)
        accessToken.let {
            val request = service?.getSearchedMovieListData("Comedy")
            request?.enqueue(object : Callback<MovieResponse> {
                override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
                    Log.i("MovieApiCall", "Fail")
                    Log.i("MovieApiCall", t.message.toString())
                }

                override fun onResponse(
                    call: Call<MovieResponse>,
                    response: Response<MovieResponse>
                ) {
                    recyclerView?.apply {
                        layoutManager = LinearLayoutManager(context)
                        adapter = response.body()?.let { it1 -> MovieAdapter(it1) }
                        adapter?.notifyDataSetChanged()
                    }
                    Log.i("MovieApiCall", "Successfull")
                    Log.i("MovieApiCall", response.toString())
                }
            })
        }


    }
}