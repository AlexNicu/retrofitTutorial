package com.iss.finestmobile.network

import retrofit2.Call
import retrofit2.http.*

interface LoginApiCallsInterface {

    @POST("token")
    fun loginUser(@Query("username") username:String,
                  @Query("password") password:String ): Call<LoginResponse>
}