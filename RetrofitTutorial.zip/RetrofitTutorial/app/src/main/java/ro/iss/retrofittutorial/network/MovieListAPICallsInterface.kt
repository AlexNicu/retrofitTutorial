package com.iss.finestmobile.network

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.QueryMap

interface MovieListAPICallsInterface {

    @GET("api/movies")
    fun getMovieListData(): Call<MovieResponse>

    @GET("api/movies")
    fun getSearchedMovieListData(@Query("category") searchValue:String): Call<MovieResponse>
}