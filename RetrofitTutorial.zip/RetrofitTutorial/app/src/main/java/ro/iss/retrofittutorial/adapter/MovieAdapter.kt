package com.iss.finestmobile.fragments.invoiceDetails.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.iss.finestmobile.network.MovieResponse
import ro.iss.retrofittutorial.R


class MovieAdapter(private val movieList: MovieResponse):
    RecyclerView.Adapter<MovieViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val inflater = LayoutInflater.from(parent.context).inflate(
            R.layout.moive_list_item,parent,false)

        return MovieViewHolder(inflater)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val invoiceResult: String = movieList.movieList[position]
        holder.bind(invoiceResult)

    }

    override fun getItemCount(): Int = movieList.movieList.size



}