package com.iss.finestmobile.fragments.invoiceDetails.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import ro.iss.retrofittutorial.R


class MovieViewHolder(itemView: View): RecyclerView.ViewHolder(
    itemView) {

    private var movieTitle: TextView? = null

    init {
        movieTitle =  itemView.findViewById(R.id.movie_title)
    }

    @SuppressLint("SetTextI18n")
    fun bind(loginResponse: String){
        movieTitle?.text = loginResponse
    }



}