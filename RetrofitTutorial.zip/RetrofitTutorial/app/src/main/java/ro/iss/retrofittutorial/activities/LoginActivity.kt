package ro.iss.retrofittutorial.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.iss.finestmobile.network.LoginApiCallsInterface
import com.iss.finestmobile.network.LoginResponse
import com.iss.finestmobile.network.RetrofitClientInstance
import kotlinx.android.synthetic.main.activity_main.*
import ro.iss.retrofittutorial.R

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        login_button_cardview.setOnClickListener {
            getLoginResponse(login_mail_input.text.toString(),login_password_input.text.toString())
        }

    }

    fun getLoginResponse(email : String, password : String){
        val service = RetrofitClientInstance().getRetrofitInstance()?.create<LoginApiCallsInterface>(
            LoginApiCallsInterface::class.java)

            val request = service?.loginUser(email,password)
            request?.enqueue(object : retrofit2.Callback<LoginResponse> {
                override fun onFailure(call: retrofit2.Call<LoginResponse>, t: Throwable) {
                    Log.i("LoginApiCall", t.message.toString())
                    Log.i("LoginApiCall", "CallFail")
                }
                override fun onResponse(
                    call: retrofit2.Call<LoginResponse>,
                    response: retrofit2.Response<LoginResponse>
                ) {
                    Log.i("LoginApiCall", response.body().toString())
                    if(response.body()?.equals("no token found")!!) {
                        Log.i("LoginApiCall", "Failed")
                    }else{
                        Log.i("LoginApiCall", "Successfull")
                        val intent = Intent(this@LoginActivity,MovieListActivity::class.java)
                        response.body()?.token?.let {
                        intent.putExtra("accessToken", it)
                        }
                        startActivity(intent)
                    }
                }

            })
        }
    }
